
<!-- App css -->
<link href="public/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="public/assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="public/assets/css/style.css" rel="stylesheet" type="text/css" />
<!-- Sweet Alert -->
<link href="public/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
<!-- DataTables -->
        <link href="public/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="public/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="public/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

</head>