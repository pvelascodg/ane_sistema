<footer class="footer">
         ©  <?php echo date("Y"); ?> AMDE <span class="text-muted d-none d-sm-inline-block float-right">Desarrollado por <a href="https://dannyyesoft.mx/"><strong>DannyyeSoft</strong></a></span>
</footer>