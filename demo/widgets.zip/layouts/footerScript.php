
        <script src="public/assets/js/jquery.min.js"></script>
        <script src="public/assets/js/bootstrap.bundle.min.js"></script>
        <script src="public/assets/js/modernizr.min.js"></script>
        <script src="public/assets/js/jquery.slimscroll.js"></script>
        <script src="public/assets/js/waves.js"></script>
        <script src="public/assets/js/jquery.nicescroll.js"></script>
        <script src="public/assets/js/jquery.scrollTo.min.js"></script>
		 <!-- Sweet-Alert  -->
        <script src="public/plugins/sweet-alert2/sweetalert2.all.min.js"></script>
        <script src="public/assets/pages/sweet-alert.init.js"></script>
		
		<!-- Required datatable js -->
        <script src="public/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="public/plugins/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="public/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="public/plugins/datatables/buttons.bootstrap4.min.js"></script>
        <script src="public/plugins/datatables/jszip.min.js"></script>
        <script src="public/plugins/datatables/pdfmake.min.js"></script>
        <script src="public/plugins/datatables/vfs_fonts.js"></script>
        <script src="public/plugins/datatables/buttons.html5.min.js"></script>
        <script src="public/plugins/datatables/buttons.print.min.js"></script>
        <script src="public/plugins/datatables/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="public/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="public/plugins/datatables/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="public/assets/pages/datatables.init.js"></script>
